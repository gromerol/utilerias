To include the Bump API localizations in your project you can simply copy each of the BumpApiLocalizable.strings files from the corresponding language .lproj folders into the .lproj folder for that language in your current project. You can copy the BumpApiLocalizable.strings files along side any Localizable.strings files that already exist for a language.
Next, go to your project right click Resources and choose "add existing files..", select each BumpApiLocalizable.strings file that you would like to add, with the encoding set to UTF-16.

Bellow are a list of the languages currently supported by the Bump API along with their country code specifiers.

Bump API - Supported Translation List:
English                    -  en
Chinese (Simplified)       -  zh-Hans
Chinese (Traditional)      -  zh-Hant
Danish                     -  da
Dutch                      -  nl
French                     -  fr
German                     -  de
Greek                      -  el
Hebrew                     -  he
Italian                    -  it
Japanese                   -  ja
Korean                     -  ko
Norwegian                  -  no
Polish                     -  pl
Portuguese                 -  pt
Russian                    -  ru
Spanish                    -  es
Swedish                    -  sv
